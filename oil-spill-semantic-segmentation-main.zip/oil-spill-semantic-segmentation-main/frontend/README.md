# MarineGuard AI - Oil Spill Detection

This repository contains the front-end for MarineGuard AI, an AI-powered oil spill detection demo built with Vite, React, TypeScript and Tailwind CSS.

Quick start (PowerShell):

```powershell
cd 'C:\Users\Salma\Downloads\ocean-guardian-ai-main'
npm install
npm run dev
```

The app will be available at http://localhost:8080/ by default.

If you plan to deploy, run `npm run build` and serve the `dist` output with your preferred static host.

Notes:
- Third-party build tool traces have been removed where they affected local runtime.
