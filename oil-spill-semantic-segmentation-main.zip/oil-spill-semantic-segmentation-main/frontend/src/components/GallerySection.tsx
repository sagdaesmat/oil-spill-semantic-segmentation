import { useState, useRef } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { X, MapPin, Calendar, Percent, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import sampleSpill1 from "@/assets/sample-spill-1.jpg";
import sampleSpill2 from "@/assets/sample-spill-2.jpg";
import sampleClean from "@/assets/sample-clean.jpg";

const galleryImages = [
  {
    id: 1,
    src: sampleSpill1,
    title: "Gulf Coast Detection",
    location: "Gulf of Mexico",
    date: "2024-03-15",
    confidence: 97.8,
    status: "spill",
  },
  {
    id: 2,
    src: sampleClean,
    title: "Mediterranean Scan",
    location: "Mediterranean Sea",
    date: "2024-03-14",
    confidence: 99.1,
    status: "clean",
  },
  {
    id: 3,
    src: sampleSpill2,
    title: "North Sea Analysis",
    location: "North Sea",
    date: "2024-03-13",
    confidence: 95.4,
    status: "spill",
  },
  {
    id: 4,
    src: sampleClean,
    title: "Caribbean Monitor",
    location: "Caribbean Sea",
    date: "2024-03-12",
    confidence: 98.7,
    status: "clean",
  },
  {
    id: 5,
    src: sampleSpill1,
    title: "Persian Gulf Alert",
    location: "Persian Gulf",
    date: "2024-03-11",
    confidence: 96.2,
    status: "spill",
  },
  {
    id: 6,
    src: sampleSpill2,
    title: "Atlantic Patrol",
    location: "Atlantic Ocean",
    date: "2024-03-10",
    confidence: 94.9,
    status: "spill",
  },
];

export function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<typeof galleryImages[0] | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const nextImage = () => {
    setCurrentIndex((prev) => (prev + 1) % galleryImages.length);
  };

  const prevImage = () => {
    setCurrentIndex((prev) => (prev - 1 + galleryImages.length) % galleryImages.length);
  };

  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background to-ocean-dark/20" />

      <div ref={ref} className="container relative z-10 mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="text-primary font-semibold text-sm uppercase tracking-wider mb-4 block">
            Detection Gallery
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            Recent <span className="gradient-text">Satellite Analysis</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Browse our latest detection results from satellite imagery around the world.
          </p>
        </motion.div>

        {/* Gallery Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image, index) => (
            <motion.div
              key={image.id}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              className="group relative rounded-2xl overflow-hidden cursor-pointer glass-card-hover"
              onClick={() => setSelectedImage(image)}
            >
              <div className="aspect-square overflow-hidden">
                <img
                  src={image.src}
                  alt={image.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
              </div>
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              {/* Status Badge */}
              <div className={`absolute top-4 right-4 px-3 py-1.5 rounded-full text-xs font-semibold ${
                image.status === "spill" 
                  ? "bg-destructive/80 text-destructive-foreground" 
                  : "bg-success/80 text-success-foreground"
              }`}>
                {image.status === "spill" ? "Spill Detected" : "Clean"}
              </div>
              
              {/* Info Overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <h3 className="font-display font-semibold text-lg text-foreground mb-2">
                  {image.title}
                </h3>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {image.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Percent className="w-4 h-4" />
                    {image.confidence}%
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Carousel Controls */}
        <div className="flex items-center justify-center gap-4 mt-8">
          <Button variant="glass" size="icon" onClick={prevImage}>
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <div className="flex gap-2">
            {galleryImages.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  currentIndex === index ? "bg-primary w-6" : "bg-muted-foreground/30"
                }`}
              />
            ))}
          </div>
          <Button variant="glass" size="icon" onClick={nextImage}>
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Fullscreen Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/90 backdrop-blur-xl"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative max-w-4xl w-full glass-card overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-4 right-4 z-10 p-2 rounded-full bg-background/50 hover:bg-background/80 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              
              <img
                src={selectedImage.src}
                alt={selectedImage.title}
                className="w-full aspect-video object-cover"
              />
              
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                      {selectedImage.title}
                    </h3>
                    <div className="flex items-center gap-4 text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {selectedImage.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {selectedImage.date}
                      </span>
                    </div>
                  </div>
                  <div className={`px-4 py-2 rounded-xl text-sm font-semibold ${
                    selectedImage.status === "spill"
                      ? "bg-destructive/20 text-destructive"
                      : "bg-success/20 text-success"
                  }`}>
                    Confidence: {selectedImage.confidence}%
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
