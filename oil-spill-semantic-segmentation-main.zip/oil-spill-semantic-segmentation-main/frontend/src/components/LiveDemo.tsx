import { useState, useRef, useCallback } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Upload, X, AlertTriangle, CheckCircle, Loader2, Download, Eye, Layers, Info } from "lucide-react";


type DetectionResult = {
  status: "clean" | "spill";
  confidence: number;
  coverage?: number;
  segmentedImage?: string;
  overlayImage?: string;
  classDistribution?: Record<string, number>;
} | null;

// API Configuration
const API_BASE_URL = "http://localhost:5000";

export function LiveDemo() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<DetectionResult>(null);
  const [viewMode, setViewMode] = useState<"original" | "mask" | "overlay">("original");
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" });

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) {
      processFile(file);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    setUploadedFile(file);
    setError(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      setUploadedImage(e.target?.result as string);
      setResult(null);
      setViewMode("original");
    };
    reader.readAsDataURL(file);
  };

  const runDetection = async () => {
    if (!uploadedFile) return;

    setIsAnalyzing(true);
    setProgress(0);
    setError(null);

    // Progress animation
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + Math.random() * 10;
      });
    }, 300);

    try {
      // Create form data with the image
      const formData = new FormData();
      formData.append("image", uploadedFile);

      // Call Flask API
      const response = await fetch(`${API_BASE_URL}/api/predict`, {
        method: "POST",
        body: formData,
      });

      clearInterval(interval);
      setProgress(100);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Detection failed");
      }

      const data = await response.json();

      setResult({
        status: data.status,
        confidence: data.confidence,
        coverage: data.coverage,
        segmentedImage: data.mask_image,
        overlayImage: data.overlay_image,
        classDistribution: data.class_distribution,
      });
    } catch (err) {
      clearInterval(interval);
      setProgress(0);
      const errorMessage = err instanceof Error ? err.message : "An error occurred";
      setError(errorMessage);
      console.error("Detection error:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetDemo = () => {
    setUploadedImage(null);
    setUploadedFile(null);
    setResult(null);
    setProgress(0);
    setViewMode("original");
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };


  return (
    <section id="demo" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-ocean-dark/30 to-background" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] bg-primary/5 rounded-full blur-3xl" />

      <div ref={sectionRef} className="container relative z-10 mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center max-w-3xl mx-auto mb-12"
        >
          <span className="text-primary font-semibold text-sm uppercase tracking-wider mb-4 block">
            Live Detection
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            Test Our <span className="gradient-text">AI Model</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Upload a satellite or aerial image to detect potential oil spills in real-time.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-4xl mx-auto"
        >
          <div className="glass-card overflow-hidden">
            {/* Upload Area */}
            {!uploadedImage ? (
              <div
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                className="p-12 border-2 border-dashed border-border/50 rounded-2xl m-6 hover:border-primary/50 transition-colors cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <div className="text-center">
                  <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
                    <Upload className="w-10 h-10 text-primary" />
                  </div>
                  <h3 className="font-display text-xl font-semibold mb-2 text-foreground">
                    Drag & Drop Image
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    or click to browse files
                  </p>
                  <p className="text-sm text-muted-foreground/60">
                    Supports: JPG, PNG, TIFF (Satellite imagery recommended)
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-6">
                {/* Image Preview */}
                <div className="relative rounded-xl overflow-hidden mb-6">
                  <AnimatePresence mode="wait">
                    <motion.img
                      key={viewMode}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      src={
                        viewMode === "original"
                          ? uploadedImage
                          : viewMode === "mask"
                            ? result?.segmentedImage || uploadedImage
                            : result?.overlayImage || uploadedImage
                      }
                      alt="Uploaded image"
                      className="w-full aspect-video object-cover"
                    />
                  </AnimatePresence>

                  {/* Overlay for analysis */}
                  {isAnalyzing && (
                    <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center">
                      <div className="text-center">
                        <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto mb-4" />
                        <p className="text-foreground font-medium mb-2">Analyzing Image...</p>
                        <div className="w-48 h-2 bg-muted rounded-full overflow-hidden">
                          <motion.div
                            className="h-full bg-primary rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: `${Math.min(progress, 100)}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Reset Button */}
                  <button
                    onClick={resetDemo}
                    className="absolute top-4 right-4 p-2 rounded-full bg-background/50 hover:bg-background/80 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* View Mode Toggle (only show if result exists) */}
                {result && result.status === "spill" && (
                  <div className="flex items-center justify-center gap-2 mb-6">
                    {[
                      { key: "original", label: "Original", icon: Eye },
                      { key: "mask", label: "Mask", icon: Layers },
                      { key: "overlay", label: "Overlay", icon: Layers },
                    ].map((mode) => (
                      <Button
                        key={mode.key}
                        variant={viewMode === mode.key ? "default" : "glass"}
                        size="sm"
                        onClick={() => setViewMode(mode.key as typeof viewMode)}
                      >
                        <mode.icon className="w-4 h-4 mr-1" />
                        {mode.label}
                      </Button>
                    ))}
                  </div>
                )}

                {/* Result Display */}
                {result && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`p-6 rounded-xl ${result.status === "clean"
                      ? "bg-success/10 border border-success/30"
                      : "bg-destructive/10 border border-destructive/30"
                      }`}
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${result.status === "clean" ? "bg-success/20" : "bg-destructive/20"
                          }`}
                      >
                        {result.status === "clean" ? (
                          <CheckCircle className="w-6 h-6 text-success" />
                        ) : (
                          <AlertTriangle className="w-6 h-6 text-destructive" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h4
                          className={`font-display text-xl font-semibold mb-2 ${result.status === "clean" ? "text-success" : "text-destructive"
                            }`}
                        >
                          {result.status === "clean"
                            ? "No Oil Spill Detected"
                            : "Oil Spill Detected!"}
                        </h4>
                        <p className="text-muted-foreground mb-4">
                          {result.status === "clean"
                            ? "Water surface appears clean. No contamination patterns identified."
                            : "Contamination patterns identified. Immediate action recommended."}
                        </p>
                        <div className="flex flex-wrap gap-4 mb-4">
                          <div className="px-4 py-2 rounded-lg bg-background/50">
                            <span className="text-sm text-muted-foreground">Confidence</span>
                            <p className="font-semibold text-foreground">
                              {result.confidence.toFixed(1)}%
                            </p>
                          </div>
                          {result.coverage !== undefined && result.coverage > 0 && (
                            <div className="px-4 py-2 rounded-lg bg-background/50">
                              <span className="text-sm text-muted-foreground">
                                Coverage Area
                              </span>
                              <p className="font-semibold text-foreground">
                                {result.coverage.toFixed(1)}%
                              </p>
                            </div>
                          )}
                        </div>

                        {/* Class Distribution */}
                        {result.classDistribution && (
                          <div className="mt-4 p-4 rounded-lg bg-background/30">
                            <h5 className="text-sm font-semibold text-foreground mb-3">Class Distribution</h5>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                              {(Object.entries(result.classDistribution) as [string, number][])
                                .filter(([_, value]) => value > 0.1)
                                .sort(([, a], [, b]) => b - a)
                                .map(([className, percentage]) => {
                                  const classColors: Record<string, string> = {
                                    "Background": "bg-gray-800",
                                    "Emulsion": "bg-green-500",
                                    "Oil": "bg-red-500",
                                    "Oil-Platform": "bg-blue-500",
                                    "Sheen": "bg-yellow-400",
                                    "Ship": "bg-purple-500"
                                  };
                                  return (
                                    <div key={className} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-background/50">
                                      <div className={`w-3 h-3 rounded-full ${classColors[className] || "bg-gray-500"}`} />
                                      <div className="flex-1 min-w-0">
                                        <span className="text-xs text-muted-foreground block truncate">{className}</span>
                                        <span className="text-sm font-semibold text-foreground">{percentage.toFixed(1)}%</span>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Actions */}
                <div className="flex flex-wrap gap-4 mt-6">
                  {!result ? (
                    <Button
                      variant="hero"
                      size="lg"
                      onClick={runDetection}
                      disabled={isAnalyzing}
                      className="flex-1"
                    >
                      {isAnalyzing ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        "Run Detection"
                      )}
                    </Button>
                  ) : (
                    <>
                      <Button variant="glass" size="lg" onClick={resetDemo} className="flex-1">
                        <Upload className="w-5 h-5" />
                        New Image
                      </Button>
                      {result.status === "spill" && (
                        <Button variant="default" size="lg" className="flex-1">
                          <Download className="w-5 h-5" />
                          Download Report
                        </Button>
                      )}
                    </>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Tooltip Info */}
          <div className="flex items-center justify-center gap-2 mt-6 text-sm text-muted-foreground">
            <Info className="w-4 h-4" />
            <span>Demo mode: Results are simulated. Connect to backend for real AI inference.</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
