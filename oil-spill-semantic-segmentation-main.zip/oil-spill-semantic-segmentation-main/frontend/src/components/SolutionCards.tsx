import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Fish, Anchor, DollarSign, Brain, Zap, TrendingUp, Clock, Shield, FileCheck } from "lucide-react";

const importanceCards = [
  {
    icon: Fish,
    title: "Marine Life Protection",
    description: "Oil spills devastate marine ecosystems, killing wildlife and destroying habitats. Early detection saves countless species.",
    color: "from-emerald-500/20 to-teal-500/20",
    borderColor: "border-emerald-500/30",
  },
  {
    icon: Anchor,
    title: "Coastal Safety",
    description: "Protect coastal communities and tourism industries from the devastating effects of oil contamination.",
    color: "from-blue-500/20 to-cyan-500/20",
    borderColor: "border-blue-500/30",
  },
  {
    icon: DollarSign,
    title: "Economic Impact",
    description: "Oil spills cost billions in cleanup and damages. Early detection minimizes financial losses significantly.",
    color: "from-amber-500/20 to-orange-500/20",
    borderColor: "border-amber-500/30",
  },
];

const solutionCards = [
  {
    icon: Brain,
    title: "CNN-Based Segmentation",
    description: "Deep learning models trained on extensive satellite datasets for pixel-level oil spill identification.",
    color: "from-primary/20 to-accent/20",
  },
  {
    icon: Zap,
    title: "Anomaly Detection",
    description: "Advanced algorithms identify unusual patterns in ocean imagery that may indicate contamination.",
    color: "from-primary/20 to-accent/20",
  },
  {
    icon: Clock,
    title: "Real-Time Inference",
    description: "Process satellite imagery in seconds, enabling rapid response to environmental emergencies.",
    color: "from-primary/20 to-accent/20",
  },
];

const impactCards = [
  {
    icon: TrendingUp,
    title: "Faster Response Time",
    description: "Reduce detection-to-action time from days to minutes with automated monitoring.",
    stat: "95% Faster",
  },
  {
    icon: Shield,
    title: "Reduced Environmental Damage",
    description: "Early intervention prevents oil spread, protecting larger ocean areas.",
    stat: "60% Less Damage",
  },
  {
    icon: FileCheck,
    title: "Regulatory Compliance",
    description: "Meet international maritime regulations with comprehensive monitoring reports.",
    stat: "100% Compliant",
  },
];

export function SolutionCards() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="solution" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-ocean-dark/20 via-background to-ocean-dark/20" />
      <div className="absolute top-1/4 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 left-0 w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl" />

      <div ref={ref} className="container relative z-10 mx-auto px-4">
        {/* Why It Matters */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="text-primary font-semibold text-sm uppercase tracking-wider mb-4 block">
              Why It Matters
            </span>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
              The Impact of <span className="gradient-text">Oil Spills</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {importanceCards.map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.1 * index }}
                className={`relative group p-8 rounded-2xl bg-gradient-to-br ${card.color} border ${card.borderColor} backdrop-blur-xl overflow-hidden`}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-transparent to-background/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative z-10">
                  <motion.div
                    whileHover={{ rotate: [0, -10, 10, 0] }}
                    transition={{ duration: 0.5 }}
                    className="w-14 h-14 rounded-2xl bg-background/50 flex items-center justify-center mb-6"
                  >
                    <card.icon className="w-7 h-7 text-foreground" />
                  </motion.div>
                  <h3 className="font-display text-xl font-semibold mb-3 text-foreground">
                    {card.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {card.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Our Solution */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mb-20"
        >
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="text-primary font-semibold text-sm uppercase tracking-wider mb-4 block">
              Our Solution
            </span>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
              Advanced <span className="gradient-text">AI Technology</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {solutionCards.map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.4 + 0.1 * index }}
                className="glass-card-hover p-8 group"
              >
                <div className="relative mb-6">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${card.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <card.icon className="w-7 h-7 text-primary" />
                  </div>
                  <div className="absolute inset-0 rounded-2xl bg-primary/20 blur-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <h3 className="font-display text-xl font-semibold mb-3 text-foreground">
                  {card.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {card.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Business Impact */}
        <motion.div
          id="impact"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="text-primary font-semibold text-sm uppercase tracking-wider mb-4 block">
              Business Impact
            </span>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
              Measurable <span className="gradient-text">Results</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {impactCards.map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.7 + 0.1 * index }}
                className="glass-card p-8 relative overflow-hidden group"
              >
                <div className="absolute top-4 right-4 px-3 py-1.5 rounded-full bg-primary/20 text-primary text-sm font-bold">
                  {card.stat}
                </div>
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <card.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-display text-xl font-semibold mb-3 text-foreground">
                  {card.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {card.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
