"""
Oil Spill Semantic Segmentation - Flask Backend
Serves the OilSpillNet model for inference on satellite/aerial imagery.
"""

import os
import io
import base64
import numpy as np
import cv2
from PIL import Image

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from flask import Flask, request, jsonify
from flask_cors import CORS

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

NUM_CLASSES = 6
TARGET_SIZE = (640, 640)

CLASS_NAMES = [
    "Background",
    "Emulsion",
    "Oil",
    "Oil-Platform",
    "Sheen",
    "Ship"
]

CLASS_COLORS = {
    0: (0, 0, 0),        # Background - Black
    1: (0, 255, 0),      # Emulsion - Green
    2: (255, 0, 0),      # Oil - Red
    3: (0, 0, 255),      # Oil-Platform - Blue
    4: (255, 255, 0),    # Sheen - Yellow
    5: (255, 0, 255),    # Ship - Magenta
}

IMAGENET_MEAN = np.array([0.485, 0.456, 0.406])
IMAGENET_STD = np.array([0.229, 0.224, 0.225])

# Model path - place your model file here
MODEL_PATH = os.path.join(os.path.dirname(__file__), "finall_model.pth")

# -----------------------------------------------------------------------------
# Model Architecture (from notebooks)
# -----------------------------------------------------------------------------

class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // reduction, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(in_channels // reduction, in_channels, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        return x * self.sigmoid(
            self.fc(self.avg_pool(x)) + self.fc(self.max_pool(x))
        )


class SpatialAttention(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg = torch.mean(x, dim=1, keepdim=True)
        max_, _ = torch.max(x, dim=1, keepdim=True)
        attn = torch.cat([avg, max_], dim=1)
        return self.sigmoid(self.conv(attn))


class ResNetEncoder(nn.Module):
    def __init__(self):
        super().__init__()
        backbone = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)

        self.stage0 = nn.Sequential(
            backbone.conv1,
            backbone.bn1,
            backbone.relu,
            backbone.maxpool
        )
        self.stage1 = backbone.layer1  # 256
        self.stage2 = backbone.layer2  # 512
        self.stage3 = backbone.layer3  # 1024
        self.stage4 = backbone.layer4  # 2048

    def forward(self, x):
        x0 = self.stage0(x)
        x1 = self.stage1(x0)
        x2 = self.stage2(x1)
        x3 = self.stage3(x2)
        x4 = self.stage4(x3)
        return x1, x2, x3, x4


class DecoderBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )
        self.ca = ChannelAttention(out_ch)
        self.sa = SpatialAttention()

    def forward(self, x):
        x = self.conv(x)
        x = self.ca(x)
        x = x * self.sa(x)
        return x


class OilSpillNet(nn.Module):
    def __init__(self, num_classes):
        super().__init__()
        self.encoder = ResNetEncoder()

        self.dec4 = DecoderBlock(2048, 512)
        self.dec3 = DecoderBlock(1024 + 512, 256)
        self.dec2 = DecoderBlock(512 + 256, 128)
        self.dec1 = DecoderBlock(256 + 128, 64)

        self.final = nn.Conv2d(64, num_classes, kernel_size=1)

    def forward(self, x):
        x1, x2, x3, x4 = self.encoder(x)

        d4 = F.interpolate(self.dec4(x4), size=x3.shape[2:], mode="bilinear", align_corners=False)
        d3 = F.interpolate(self.dec3(torch.cat([x3, d4], dim=1)), size=x2.shape[2:], mode="bilinear", align_corners=False)
        d2 = F.interpolate(self.dec2(torch.cat([x2, d3], dim=1)), size=x1.shape[2:], mode="bilinear", align_corners=False)
        d1 = self.dec1(torch.cat([x1, d2], dim=1))

        out = self.final(
            F.interpolate(d1, size=x.shape[2:], mode="bilinear", align_corners=False)
        )
        return out


# -----------------------------------------------------------------------------
# Load Model
# -----------------------------------------------------------------------------

model = None

def load_model():
    global model
    if not os.path.exists(MODEL_PATH):
        print(f"WARNING: Model file not found at {MODEL_PATH}")
        print("Please place 'finall_model.pth' in the backend directory.")
        return False
    
    try:
        model = OilSpillNet(NUM_CLASSES).to(DEVICE)
        model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
        model.eval()
        print("Model loaded successfully!")
        return True
    except Exception as e:
        print(f"Error loading model: {e}")
        return False


# -----------------------------------------------------------------------------
# Inference Utilities
# -----------------------------------------------------------------------------

def preprocess_image(image: Image.Image) -> tuple[torch.Tensor, tuple[int, int]]:
    """Preprocess image for model inference."""
    # Store original size
    original_size = image.size  # (width, height)
    
    # Convert to RGB if needed
    if image.mode != "RGB":
        image = image.convert("RGB")
    
    # Convert to numpy array
    img = np.array(image)
    
    # Resize to target size
    img = cv2.resize(img, TARGET_SIZE)
    
    # Normalize
    img = img / 255.0
    img = (img - IMAGENET_MEAN) / IMAGENET_STD
    
    # Convert to tensor (HWC -> CHW)
    img_tensor = torch.from_numpy(img).permute(2, 0, 1).float().unsqueeze(0).to(DEVICE)
    
    return img_tensor, original_size


def postprocess_mask(pred: np.ndarray, original_size: tuple[int, int]) -> np.ndarray:
    """Resize prediction mask to original image size."""
    # Resize to original size (width, height)
    mask = cv2.resize(pred.astype(np.uint8), original_size, interpolation=cv2.INTER_NEAREST)
    return mask


def mask_to_rgb(mask: np.ndarray) -> np.ndarray:
    """Convert class mask to RGB image."""
    h, w = mask.shape
    rgb = np.zeros((h, w, 3), dtype=np.uint8)
    
    for cls_id, color in CLASS_COLORS.items():
        rgb[mask == cls_id] = color
    
    return rgb


def create_overlay(image: np.ndarray, mask: np.ndarray, alpha: float = 0.5) -> np.ndarray:
    """Create overlay of mask on original image."""
    mask_rgb = mask_to_rgb(mask)
    overlay = image.copy()
    
    # Only overlay non-background pixels
    non_bg_mask = mask > 0
    overlay[non_bg_mask] = (
        overlay[non_bg_mask] * (1 - alpha) +
        mask_rgb[non_bg_mask] * alpha
    ).astype(np.uint8)
    
    return overlay


def calculate_class_distribution(mask: np.ndarray) -> dict:
    """Calculate percentage of each class in the mask."""
    total_pixels = mask.size
    distribution = {}
    
    for i, name in enumerate(CLASS_NAMES):
        pct = (mask == i).sum() / total_pixels * 100
        distribution[name] = round(pct, 2)
    
    return distribution


def numpy_to_base64(img: np.ndarray, format: str = "PNG") -> str:
    """Convert numpy array to base64 encoded string."""
    if img.shape[2] == 3:  # RGB
        pil_img = Image.fromarray(img)
    else:
        pil_img = Image.fromarray(img)
    
    buffer = io.BytesIO()
    pil_img.save(buffer, format=format)
    buffer.seek(0)
    
    base64_str = base64.b64encode(buffer.getvalue()).decode()
    return f"data:image/{format.lower()};base64,{base64_str}"


# -----------------------------------------------------------------------------
# API Endpoints
# -----------------------------------------------------------------------------

@app.route("/api/health", methods=["GET"])
def health_check():
    """Health check endpoint."""
    return jsonify({
        "status": "healthy",
        "model_loaded": model is not None,
        "device": str(DEVICE)
    })


@app.route("/api/predict", methods=["POST"])
def predict():
    """Run inference on uploaded image."""
    # Check if model is loaded
    if model is None:
        return jsonify({"error": "Model not loaded. Please ensure finall_model.pth is in the backend directory."}), 500
    
    # Check if image was uploaded
    if "image" not in request.files:
        return jsonify({"error": "No image file provided"}), 400
    
    file = request.files["image"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400
    
    try:
        # Read and preprocess image
        image = Image.open(file.stream)
        original_np = np.array(image.convert("RGB"))
        
        img_tensor, original_size = preprocess_image(image)
        
        # Run inference
        with torch.no_grad():
            output = model(img_tensor)
            pred = torch.argmax(output, dim=1)[0].cpu().numpy()
        
        # Postprocess
        mask = postprocess_mask(pred, original_size)
        
        # Create visualization images
        mask_rgb = mask_to_rgb(mask)
        overlay = create_overlay(original_np, mask)
        
        # Calculate statistics
        class_dist = calculate_class_distribution(mask)
        
        # Determine if there's a spill (any non-background class)
        non_bg_percentage = 100 - class_dist["Background"]
        has_spill = non_bg_percentage > 1.0  # More than 1% non-background
        
        # Calculate confidence (max probability of detected class)
        with torch.no_grad():
            probs = F.softmax(output, dim=1)
            max_prob = probs.max().item() * 100
        
        # Prepare response
        response = {
            "status": "spill" if has_spill else "clean",
            "confidence": round(max_prob, 1),
            "coverage": round(non_bg_percentage, 1) if has_spill else 0,
            "mask_image": numpy_to_base64(mask_rgb),
            "overlay_image": numpy_to_base64(overlay),
            "class_distribution": class_dist
        }
        
        return jsonify(response)
    
    except Exception as e:
        print(f"Error during prediction: {e}")
        return jsonify({"error": str(e)}), 500


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    print("Starting Oil Spill Detection Backend...")
    load_model()
    app.run(host="0.0.0.0", port=5000, debug=True)
