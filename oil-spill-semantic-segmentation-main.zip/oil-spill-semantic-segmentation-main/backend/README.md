# Flask Backend for Oil Spill Semantic Segmentation

This backend serves the trained OilSpillNet model for semantic segmentation of oil spills in satellite/aerial imagery.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Place your trained model file (`finall_model.pth`) in this directory.

3. Run the server:
```bash
python app.py
```

The server will start at `http://localhost:5000`.

## API Endpoints

### POST /api/predict

Upload an image for oil spill detection.

**Request:**
- Content-Type: `multipart/form-data`
- Body: `image` - The image file to analyze

**Response:**
```json
{
  "status": "spill" | "clean",
  "confidence": 95.5,
  "coverage": 23.4,
  "mask_image": "data:image/png;base64,...",
  "overlay_image": "data:image/png;base64,...",
  "class_distribution": {
    "Background": 76.6,
    "Emulsion": 5.2,
    "Oil": 12.1,
    "Oil-Platform": 0.0,
    "Sheen": 6.1,
    "Ship": 0.0
  }
}
```
